
lower_limit = input("Enter the lower limit of integration: ");
upper_limit = input("Enter the upper limit of integration: ");

% Assuming f is a function handle or an array of function values
f = @(x)5.*x.*exp(-2.*x);  % Define your function here, or replace it with your actual function
h = 0.8;
% Generate x values over the integration interval
x = lower_limit:h:upper_limit;

% Evaluate the function at the x values
y = f(x);  

% Calculate the trapezoidal rule for numerical integration

I = h/2 * (y(1) + 2*sum(y(2:end-1)) + y(end))

% Display the result of numerical integration
disp('Result of numerical integration using the trapezoidal rule:');
disp(I);


% Define the function
f = @(x) 5 .* x .* exp(-2 .* x);

% Define the interval [a, b]
a = 0.4;  % Lower limit
b = 1.2;  % Upper limit

% Calculate the average rate of change of the function over the interval [a, b]
average_rate_of_change = (f(b) - f(a)) / (b - a);

% Find the derivative of the function symbolically
syms x;
f_derivative = diff(f(x), x);

% Find the value of c using the Mean Value Theorem
c = solve(f_derivative == average_rate_of_change, x);

% Display the result
fprintf('The value of c where f''(c) = Average Rate of Change is: %.4f\n', double(c));

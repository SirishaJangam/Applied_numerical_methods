
function result = romberg_integration(f, a, b, n)
    % Romberg integration to approximate the definite integral of f from a to b.
    
    % Initialize the Romberg table
    R = zeros(n, n);
    
    % Compute the first column of the table using the trapezoidal rule
    h = b - a;
    R(1, 1) = 0.5 * h * (f(a) + f(b));
    
    % Fill in the rest of the table
    for i = 2:n
        h = h / 2;
        sum = 0;
        for k = 1:2^(i-2)
            sum = sum + f(a + (2*k - 1)*h);
        end
        R(i, 1) = 0.5 * R(i-1, 1) + sum * h;
    end
    
    % Apply Richardson extrapolation
    for j = 2:n
        for i = j:n
            R(i, j) = R(i, j-1) + (R(i, j-1) - R(i-1, j-1)) / ((4^(j-1)) - 1)
        end
    end
    
    % The final result is in the bottom-right corner of the table
    result = R(n, n);
end



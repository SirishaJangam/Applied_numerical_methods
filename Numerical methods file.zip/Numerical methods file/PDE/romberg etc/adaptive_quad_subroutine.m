tol = 1E-10;
a = 1; % Define integration limits
b = 2;

[I, ~] = adaptive_quadrature(a, b, tol)

disp('Approximate integral:');
disp(I);

function y = f(x)
    % Define the function
    y = x + log(x);
end

function [integral, error] = adaptive_quadrature(a, b, tol)
    % Compute function values at endpoints and midpoint
    fa = f(a);
    fb = f(b);
    c = (a + b) / 2;
    fc = f(c);
    
    % Compute initial Simpson's rule approximations
    h1 = b - a;
    h2 = h1 / 2;
    fd = f((a + c) / 2);
    fe = f((c + b) / 2);
    I1 = h1 / 6 * (fa + 4 * fc + fb);
    I2 = h2 / 6 * (fa + 4 * fd + 2 * fc + 4 * fe + fb);
    
    % Compute error
    error = abs(I1 - I2);
    
    % Check if error is within tolerance
    if error < tol
        % If error is small enough, return the refined approximation
        integral = I2 + error / 15;
    else
        % If not, recursively call adaptive_quadrature on subintervals
        [Ia, Ea] = adaptive_quadrature(a, c, tol);
        [Ib, Eb] = adaptive_quadrature(c, b, tol);
        
        % Combine results from subintervals
        integral = Ia + Ib;
        error = max(Ea, Eb);
    end
end
    
% Define step size and generate x values
h = input("Provide the step size: ");
x = 0:h:4;
n = length(x);

% Initialize arrays for numerical solutions
eulers = zeros(n,1);
heuns = zeros(n,1);
midpoint_method = zeros(n,1);
ralston_method = zeros(n,1);

% Define the function f(x, y)
f = @(x, y) -2*x.^3 + 12*x.^2 - 20*x + 8.5;

% Calculate exact solution
exact_value = -0.5*x.^4 + 4*x.^3 - 10*x.^2 + 8.5*x + 1;

% Perform Euler's method
eulers(1) = input("Give the initial value: ");
for i = 1:n-1
    eulers(i+1) = eulers(i) + f(x(i), eulers(i)) * h;
end

% Perform Heun's method
heuns(1) = eulers(1);
for i = 1:n-1
    k1 = f(x(i), heuns(i));
    k2 = f(x(i) + h, heuns(i) + h * k1);
    heuns(i+1) = heuns(i) + h/2 * (k1 + k2);
end

% Perform Midpoint method
midpoint_method(1) = eulers(1);
for i = 1:n-1
    k1 = f(x(i), midpoint_method(i));
    y_temp = midpoint_method(i) + k1 * h/2;
    k2 = f(x(i) + h/2, y_temp);
    midpoint_method(i+1) = midpoint_method(i) + k2 * h;
end

% Perform Ralston method
ralston_method(1) = eulers(1);
for i = 1:n-1
    k1 = f(x(i), ralston_method(i));
    k2 = f(x(i) + 3/4 * h, ralston_method(i) + 3/4 * h * k1);
    ralston_method(i+1) = ralston_method(i) + h * (1/3 * k1 + 2/3 * k2);
end

% Calculate truncation error percentages
truncation_error_eulers = abs(exact_value - eulers) ./ abs(exact_value) * 100;
truncation_error_heuns = abs(exact_value - heuns) ./ abs(exact_value) * 100;
truncation_error_midpoint = abs(exact_value - midpoint_method) ./ abs(exact_value) * 100;
truncation_error_ralston = abs(exact_value - ralston_method) ./ abs(exact_value) * 100;

% Plot results
figure
plot(x, exact_value, 'p--', 'LineWidth', 2)
hold on
plot(x, eulers, 'r-', 'LineWidth', 1.5)
plot(x, heuns, 'b--', 'LineWidth', 1.5)
plot(x, midpoint_method, 'g-', 'LineWidth', 1.5)
plot(x, ralston_method, 'y--', 'LineWidth', 1.5)
hold off
xlabel('x')
ylabel('y')
legend('Exact', 'Euler', 'Heun', 'Midpoint', 'Ralston')
title('Numerical Solutions')

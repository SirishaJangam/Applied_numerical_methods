h = input("Provide the step size: ");
x = 0:h:4; % Generate x values using the step size
n = length(x);
y = zeros(n,1); %%%%%% y is predicted
y(1) = 1; % Initial condition: y(0) = 2

f = @(x, y) -2*x.^3 + 12*x.^2 - 20*x + 8.5 ; % Define your function f(x, y)

% rolstan method
for i = 1:n-1
    k1 = f(x(i), y(i)); % slope at the beginning of the interval
    k2 = f(x(i) +3/4* h, y(i) + 3/4*h * k1); % slope at the end of the interval
    y(i+1) = y(i) + h * (1/3*k1 + 2/3*k2); % Calculate next y using the average of the slopes
end

y_exact = zeros(n,1);
for i = 1:n
    y_exact(i) = -0.5*x(i).^4 + 4*x(i).^3 - 10*x(i).^2 + 8.5*x(i) + 1;
end

% Calculate truncation error percentage
truncation_error = abs(y_exact - y);  % Absolute difference between exact and numerical solution
truncation_error_percentage = (truncation_error ./ y_exact) * 100;  % Calculate percentage error

% Display the result
[y, y_exact, truncation_error_percentage]

% Plot exact and predicted solutions with error percentage separately
figure
subplot(2, 1, 1)
plot(x, y, 'r-', x, y_exact, 'b--')
xlabel('x')
ylabel('y')
legend('Exact solution', 'Predicted solution','error')
title('Exact vs. Predicted solution and error')

subplot(2, 1, 2)
plot(x, truncation_error_percentage, 'g-')
xlabel('x')
ylabel('Error (%)')
title('Error Percentage')

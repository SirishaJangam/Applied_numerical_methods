%% Crout's Method

% Input matrix A
A = input("Enter the matrix A: ");
n = length(A);

% Initialize matrices L and U
L = zeros(n, n);
U = zeros(n, n);

% Initialize diagonal elements of L to 1
for a = 1:n
    L(a, a) = 1;
end

% Perform Crout's method
L(:, 1) = A(:, 1);
U(1, :) = A(1, :) / L(1, 1);

for i = 2:n
    for k = i:n
        L(k, i) = A(k, i) - L(k, 1:i-1) * U(1:i-1, i);
    end
    for j = i:n
        U(i, j) = (A(i, j) - L(i, 1:i-1) * U(1:i-1, j)) / L(i, i);
    end
end

L,U

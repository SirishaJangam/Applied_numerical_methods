% Crout's Method for Inverse Calculation

% Input matrix A
A = input("Enter the matrix A: ");
B = input("Enter the matrix B: ");
n = length(A);

% Initialize matrices L and U
L = zeros(n, n);
U = zeros(n, n);

% Initialize diagonal elements of L to 1
for a = 1:n
    L(a, a) = 1;
end

% Perform Crout's method
L(:, 1) = A(:, 1);
U(1, :) = A(1, :) / L(1, 1);

for i = 2:n
    for k = i:n
        L(k, i) = A(k, i) - L(k, 1:i-1) * U(1:i-1, i);
    end
    for j = i:n
        U(i, j) = (A(i, j) - L(i, 1:i-1) * U(1:i-1, j)) / L(i, i);
    end
end
L,U
% Calculate inverse using Crout's method
A_inv = zeros(n, n);
for j = 1:n
    B_j = zeros(n, 1);
    B_j(j) = 1; % Create a unit vector corresponding to the j-th column of the identity matrix
    Y = zeros(n, 1);
    % Solve Ly = B for y
    for i = 1:n
        Y(i) = (B_j(i) - L(i, 1:i-1) * Y(1:i-1)) / L(i, i);
    end
    X = zeros(n, 1);
    % Solve Ux = y for x
    for i = n:-1:1
        X(i) = (Y(i) - U(i, i+1:n) * X(i+1:n)) / U(i, i);
    end
    A_inv(:, j) = X;
end

% Calculate the product of the inverse of A and B
result = A_inv * B;

% Display the result
disp('concentration of each reactor is:');
disp(result);

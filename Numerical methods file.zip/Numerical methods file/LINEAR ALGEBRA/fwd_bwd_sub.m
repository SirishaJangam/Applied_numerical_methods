%% Forward Substitution

L = input("Enter L matrix: ");
B = input("Enter B matrix: ");
n = length(B);
D = zeros(n, 1);

for i = 1:n
    c = L(i, :) * D;  % Perform the dot product between the corresponding elements of L and D
    D(i) = (B(i) - c) / L(i, i);
end

%% Backward Substitution

U = input("Enter U matrix: ");
X = zeros(n, 1);

for i = n:-1:1
    c = U(i, :) * X;  % Perform the dot product between the corresponding elements of U and X
    X(i) = (D(i) - c) / U(i, i);
end

X, D  % Display the solution vectors X and D

syms x y

x=(0:0.1:1);

eq1= @(x) (6-2*x)/4;
eq2= @(x) 5-4*x;
y=eq1(x);
y_2=eq2(x);

figure;
plot(x, y, '-r', 'LineWidth', 2, 'displayname', '2x+4y=6');
hold on;
plot(x, y_2, '-b', 'LineWidth', 2, 'displayname','4x+y=5');


xlabel('x');
ylabel('y');
title('Plot of Two Linear Equations');
legend('show');
grid on;